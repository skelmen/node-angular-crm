"use strict";
// interface ILength {
//     length: number;
// }
//
// function getLength(variable: ILength): void {
//     console.log('getLength', variable.length);
// }
//
// const box = {
//     name: 'WFM',
//     length: 20
// };
//
// getLength(box);
// getLength([1, 2, 3]);
var user = {
    name: 'WFM',
    age: 20
};
