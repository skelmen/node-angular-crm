// string
var str = 'string!';
// number
var num = 10;
// boolean
var isTrue = true;
var isFalse = false;
// other
var unknown = '1';
unknown = true;
