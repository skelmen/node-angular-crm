"use strict";
var user = {
    name: 'WFM',
    age: 20
};
function logUser(user) {
    console.log(user.name + ' ' + user.age);
}
logUser(user);
var variable;
variable = 1;
variable = '';
//# sourceMappingURL=index.js.map